
from fastapi  import APIRouter,status,Depends,HTTPException
from .database import get_connection
from . import models,schema
from sqlalchemy.orm import Session

router= APIRouter(tags=["User Read Operation"])


@router.get('/loadusers')
def loadUsers(db:Session=Depends(get_connection)):
    users=db.query(schema.UserApp).all()
    
    return {"message":users}

@router.get('/finduser/{name}')
def loadUsers(name:str,db:Session=Depends(get_connection)):
    users=db.query(schema.UserApp).filter(schema.UserApp.uname == name).first()
    if users == None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,detail="OOPS...! given user not found")
    return {"message":users}
