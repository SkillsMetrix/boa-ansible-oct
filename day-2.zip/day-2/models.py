from pydantic import BaseModel 
class User(BaseModel):
    uname:str
    password:str
    email:str
    city: str