from fastapi import FastAPI
from . import CUD,Readops,schema
from .database import engine
app= FastAPI()

schema.Base.metadata.create_all(bind=engine)
app.include_router(CUD.router)
app.include_router(Readops.router)