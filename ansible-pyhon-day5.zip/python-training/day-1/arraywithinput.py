# declare an empty array
use_number=[]
#ask the user ,how many numbers wana add?

data= int(input('How many numbers you wana add?  '))
for i in range(data):
    num= int(input (f"Enter numbers  "))
    use_number.append(num)

for nd in use_number:
    if(nd%2==0):
        print(f"{nd} is even")
    else:
        print(f"{nd} is odd")

# do the addtion of all the numbers in user_number

total=0
for data in use_number:
    total += nd
print(f"Addition is : {total}")