

def sumOfArray(arr):
    total=0
    for num in arr:
        total +=num
    return total

numbers=[13,41,54,31]

result= sumOfArray(numbers)
print(result)