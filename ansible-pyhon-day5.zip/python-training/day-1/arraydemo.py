

userNames=['admin','manager','qa']

print(userNames)
for users in userNames:
    print(users)
