a= int(input('Enter the first number '))
b= int(input('Enter the second number '))

c=a+b

print(f"Addition is : {c}")