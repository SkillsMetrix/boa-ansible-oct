from RBIBank import RBI

class SBI(RBI):
    def openFD(self):
        print('SBI Bank open FD Account')
    def checkBalance(self):
        print('checking balance in SBI')
    def withdraw(self,amount):
        print(f"amount withdrawn {self.amount}")
    
    def deposit(self,amount):
        print(f"amount deposit {self.amount}")