from RBIBank import RBI

class HDFC(RBI):
    def openFD(self):
        print('HDFC Bank open FD Account')
    def checkBalance(self):
        print('checking balance in HDFC')