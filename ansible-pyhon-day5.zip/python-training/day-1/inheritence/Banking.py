from SBIBank import SBI
from HDFCBank import HDFC
publicSectorBank= SBI()
publicSectorBank.openFD()
publicSectorBank.checkBalance()