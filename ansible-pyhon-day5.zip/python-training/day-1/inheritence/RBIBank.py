from abc import ABC,abstractmethod

class RBI(ABC):
    @abstractmethod
    def withdraw(amount):
        pass
    @abstractmethod
    def deposit(amount):
        pass
    @abstractmethod
    def checkBalance(self):
        pass