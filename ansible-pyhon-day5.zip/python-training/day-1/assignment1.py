userage= int(input('Enter User Age'))

if userage <=0:
    print('Enter Valid Age')
elif userage <18:
    print('Not Allowed to vote')
elif userage >=18 and userage <80:
    print('You Can Vote')
else:
    print('Senior Citizen')