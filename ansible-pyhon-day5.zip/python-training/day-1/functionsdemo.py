def showWelcome():
    print('welcome to the function')

showWelcome()

def calc(x,y):
    return x+y

print(calc(12,13))