
# class declaration
class DemoClass:
    name='shashi'
    email='shashi@mail.com'

    # constructor declarations

    def __init__(self,city,pincode):
        self.city=city
        self.pincode=pincode

    # declare functions
    #def showData(self):
    #    print(self.name,self.email,self.city,self.pincode)
    
    # function to convert object into human readable string

    def __str__(self):
        return f"{self.name},{self.email},{self.city},{self.pincode}"


#object creation

demo= DemoClass('pune',412345)
print(demo)
#demo.showData()




