
from fastapi  import APIRouter,status,Depends,HTTPException
from .database import get_connection
from . import models,schema,utils
from sqlalchemy.orm import Session
router= APIRouter(tags=["User Create,Update and Delete Application"])


@router.post('/adduser')
def addUserToDB(payload:models.User,db:Session=Depends(get_connection)):
    hp= utils.hash(payload.password)
    payload.password=hp
    postdata=schema.UserApp(**payload.model_dump())
    db.add(postdata)
    db.commit()

    return {"message":"User Added"}

@router.delete('/deleteuser/{name}')
def deleteUser(name:str,db:Session=Depends(get_connection)):
    users=db.query(schema.UserApp).filter(schema.UserApp.uname == name).first()
    if users == None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,detail="OOPS...! given user not found")
    db.delete(users)
    db.commit()
    return {"message":"user deleted"}

@router.put('/updateuser/{name}')
def updateUser(name:str,payload:models.User,db:Session=Depends(get_connection)):
    users=db.query(schema.UserApp).filter(schema.UserApp.uname == name)
    stu= users.first()
    if users == None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,detail="OOPS...! given user not found")
    
    users.update(payload.model_dump())
   
    db.commit()
    return {"message":"user updated"}