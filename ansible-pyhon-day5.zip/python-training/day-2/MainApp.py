from fastapi import FastAPI
from . import Readops,schema,CUD
from .database import engine
app= FastAPI()

schema.Base.metadata.create_all(bind=engine)
app.include_router(CUD.router)
app.include_router(Readops.router)